export default function MainMenuFilter(){
    return(
        <div className="main-menu-filter">
                <div className="container">
                    <ul>
                        <li className="active">غذای اصلی</li>
                        {/* <li>پیش غذا</li> */}
                        {/* <li>دسر</li> */}
                        {/* <li>نوشیدنی</li> */}
                    </ul>
                </div>
            </div>
    )
}